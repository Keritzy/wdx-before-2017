import lgm.cmu.spotagram.db.DBFacade;
import lgm.cmu.spotagram.model.User;

/**
 * DBTest.java 	Version <1.00>	����1:58:25
 *
 * Copyright(C) 2015-2016  All rights reserved. 
 * Lei YU is a graduate student majoring in Electrical and Electronics Engineering, 
 * from the ECE department, Carnegie Mellon University, PA 15213, United States.
 *
 * Email: leiyu@andrew.cmu.edu
 */
public class DBTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User user = new User("jack", "jack", false, "xxxx/", "xxxx");
		
		if (DBFacade.delete(user)) {
			System.out.println("Success");
		} else {
			System.out.println("Fail");
		}
		
		System.out.println(user.getId());
	}

}
