package lgm.cmu.spotagram.model;

import java.sql.Date;

import lgm.cmu.spotagram.db.Column;
import lgm.cmu.spotagram.db.Table;
import lgm.cmu.spotagram.db.Column.DataType;

/**
 * User.java 	Version <1.00>	����1:05:31
 *
 * Copyright(C) 2015-2016  All rights reserved. 
 * Lei YU is a graduate student majoring in Electrical and Electronics Engineering, 
 * from the ECE department, Carnegie Mellon University, PA 15213, United States.
 *
 * Email: leiyu@andrew.cmu.edu
 */

@Table(name="note")
public class Note extends Model {
	
	@Column(name="longitude", type =DataType.FLOAT)
	private float longitude;
	
	@Column(name="latitude", type =DataType.FLOAT)
	private float latitude;
	
	@Column(name="date", type =DataType.DATE)
	private Date date;
	
	@Column(name="content", type =DataType.TEXT)
	private String content;
	
	@Column(name="type", type =DataType.INTEGER)
	private String type;
	
	@Column(name="userid", type =DataType.INTEGER)
	private int userid;
	
	@Column(name="info", type =DataType.TEXT)
	private String info;
	
	public Note(float longitude, float latitude, Date date,
			String content, String type, int userid, String info) {
		super();
		this.longitude = longitude;
		this.latitude = latitude;
		this.date = date;
		this.content = content;
		this.type = type;
		this.userid = userid;
		this.info = info;
	}

	public float getLongitude() {
		return longitude;
	}

	public void setLongitude(float longitude) {
		this.longitude = longitude;
	}

	public float getLatitude() {
		return latitude;
	}

	public void setLatitude(float latitude) {
		this.latitude = latitude;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}
	
}
