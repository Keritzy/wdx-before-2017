package lgm.cmu.spotagram.utils;
/**
 * ConstantValue.java 	Version <1.00>	����2:34:09
 *
 * Copyright(C) 2015-2016  All rights reserved. 
 * Lei YU is a graduate student majoring in Electrical and Electronics Engineering, 
 * from the ECE department, Carnegie Mellon University, PA 15213, United States.
 *
 * Email: leiyu@andrew.cmu.edu
 */
public class ConstantValue {
	
}
