/**
 * 
 */
package adapter;

/**
 * @author Da Wang
 * @andrew_id dawang
 * 
 * Interface with fix method implemented by exception.FixHelper
 */
public interface FixAuto {
	public void fix(int errno);
}
