/**
 * 
 */
package dawang.assignment2.prototype;

/**
 * @author Da Wang
 * @andrew_id dawang
 * 
 * This is a abstract class to fit the OOP design. For example, if I have a 
 * Teacher class, it will also inherit this abstract class People. 
 */
public abstract class People {

}
