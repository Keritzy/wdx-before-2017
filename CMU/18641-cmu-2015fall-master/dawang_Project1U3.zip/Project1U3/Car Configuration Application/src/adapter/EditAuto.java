/**
 * 
 */
package adapter;

import scale.EditOption.EditOptionEnumerator;

/**
 * @author Da Wang
 * @andrew_id dawang
 * 
 * The interface for thread editing
 */
public interface EditAuto {
	public void edit(EditOptionEnumerator editOptionEnum,String[] args);
}
