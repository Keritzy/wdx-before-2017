# Assignment1 - Coin Toss

## Platform

+ Operating System: OS X Yosemite 10.10.5
+ Eclipse Version: Java EE IDE Mars Release(4.5.0)
+ Java Version: JavaSE-1.7

## File Description

+ Eclipse Project
    + bin(folder)
    + src(folder)
+ Class Diagram
    + class_diagram.jpg
+ Test Output
    + test_output.txt
+ Readme

## Code Design

Basically I follow the instruction given by the assignment.

For the Simulator class, in order to add/modify testcases easily, I write a separate method for simulation process and use an array to record the different testcases. As it is, the whole process will be nice and clean.

With the 4 testcases: 20 10 0 -1, the simulator can work well with correct output.
