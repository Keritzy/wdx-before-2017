/**
 * 
 */
package adapter;

import server.AutoServer;

/**
 * @author Da Wang
 * @andrew_id dawang
 * 
 * Have no lines of code, keep empty
 */
public class BuildAuto extends ProxyAutomobile 
implements CreateAuto, UpdateAuto, FixAuto, EditAuto, AutoServer, DatabaseAuto {

}
