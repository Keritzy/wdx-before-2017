# README

andrew id: dawang
date: 2016-01-17

## Information

I use the ATMMachine class to control all the hardware for the ATM and the other two import classes are ATMTransmition and Account which both have subclasses for different purpose.

I only draw the top-level design as the baseline for the following project.
